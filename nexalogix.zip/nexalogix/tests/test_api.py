import os
import tempfile

fd, dbpath = tempfile.mkstemp(suffix=".db")
os.close(fd)
os.environ["DATABASE_URL"] = f"sqlite:///{dbpath}"
os.environ["DISPATCH_API_KEY"] = "test-secret"
from fastapi.testclient import TestClient
from app.main import app


def test_dispatch_flow():
    with TestClient(app) as client:
        assert client.get("/health").status_code == 200
        assert client.get("/drivers").status_code == 401
        headers = {"X-API-Key": "test-secret"}
        driver = client.post("/drivers", json={"name": "Alex"}, headers=headers).json()
        vehicle = client.post("/vehicles", json={"unit_number": "T-1", "capacity_lbs": 5000}, headers=headers).json()
        customer = client.post("/customers", json={"name": "Acme"}, headers=headers).json()
        load_response = client.post("/loads", json={"reference": "L-1", "customer_id": customer["id"], "origin": "Newark, NJ", "destination": "Trenton, NJ", "rate_usd": 600, "driver_pay_usd": 200}, headers=headers)
        assert load_response.status_code == 201
        load_id = load_response.json()["id"]
        assigned = client.post(f"/loads/{load_id}/assign", json={"driver_id": driver["id"], "vehicle_id": vehicle["id"]}, headers=headers)
        assert assigned.json()["status"] == "assigned"
        for status in ("picked_up", "delivered"):
            assert client.post(f"/loads/{load_id}/status", json={"status": status}, headers=headers).status_code == 200
        dashboard = client.get("/dashboard", headers=headers).json()
        assert dashboard["estimated_margin_usd"] == 400
        assert client.post(f"/loads/{load_id}/status", json={"status": "posted"}, headers=headers).status_code == 409
