"""NexaLogix: starter dispatch and fleet management API."""
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from enum import Enum
from os import getenv
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from sqlmodel import Field, Session, SQLModel, create_engine, select

DATABASE_URL = getenv("DATABASE_URL", "sqlite:///./dispatch.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def authorize(key: Optional[str] = Depends(api_key_header)):
    expected = getenv("DISPATCH_API_KEY", "")
    if not expected or key != expected:
        raise HTTPException(status_code=401, detail="Invalid API key or server key not configured")


def session_dep():
    with Session(engine) as session:
        yield session


class LoadStatus(str, Enum):
    posted = "posted"
    assigned = "assigned"
    picked_up = "picked_up"
    delivered = "delivered"
    cancelled = "cancelled"


class Driver(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(min_length=1)
    phone: str = ""
    email: str = ""
    active: bool = True
    license_class: str = ""
    notes: str = ""


class Vehicle(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    unit_number: str = Field(index=True)
    type: str = "box_truck"
    plate: str = ""
    capacity_lbs: Optional[int] = None
    liftgate: bool = False
    active: bool = True
    insurance_expiry: Optional[str] = None
    inspection_expiry: Optional[str] = None


class Customer(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(min_length=1)
    contact_name: str = ""
    email: str = ""
    phone: str = ""
    billing_address: str = ""


class Load(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    reference: str = Field(index=True)
    customer_id: int = Field(foreign_key="customer.id")
    driver_id: Optional[int] = Field(default=None, foreign_key="driver.id")
    vehicle_id: Optional[int] = Field(default=None, foreign_key="vehicle.id")
    origin: str
    destination: str
    pickup_at: Optional[datetime] = None
    delivery_at: Optional[datetime] = None
    status: LoadStatus = LoadStatus.posted
    rate_usd: float = Field(default=0, ge=0)
    driver_pay_usd: float = Field(default=0, ge=0)
    expenses_usd: float = Field(default=0, ge=0)
    miles: float = Field(default=0, ge=0)
    weight_lbs: Optional[int] = Field(default=None, ge=0)
    notes: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Expense(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    load_id: Optional[int] = Field(default=None, foreign_key="load.id")
    category: str
    amount_usd: float = Field(ge=0)
    description: str = ""
    incurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class LoadEvent(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    load_id: int = Field(foreign_key="load.id")
    status: LoadStatus
    note: str = ""
    recorded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Assignment(SQLModel):
    driver_id: int
    vehicle_id: int


class StatusUpdate(SQLModel):
    status: LoadStatus
    note: str = ""


@asynccontextmanager
async def lifespan(app: FastAPI):
    SQLModel.metadata.create_all(engine)
    yield


app = FastAPI(title="NexaLogix API", version="0.1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=[s.strip() for s in getenv("CORS_ORIGINS", "http://localhost:3000").split(",")], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
def health():
    return {"status": "ok", "service": "nexalogix"}


@app.post("/drivers", response_model=Driver, status_code=201, dependencies=[Depends(authorize)])
def add_driver(item: Driver, db: Session = Depends(session_dep)):
    item.id = None
    db.add(item); db.commit(); db.refresh(item)
    return item


@app.get("/drivers", response_model=list[Driver], dependencies=[Depends(authorize)])
def drivers(db: Session = Depends(session_dep)):
    return db.exec(select(Driver)).all()


@app.post("/vehicles", response_model=Vehicle, status_code=201, dependencies=[Depends(authorize)])
def add_vehicle(item: Vehicle, db: Session = Depends(session_dep)):
    item.id = None
    db.add(item); db.commit(); db.refresh(item)
    return item


@app.get("/vehicles", response_model=list[Vehicle], dependencies=[Depends(authorize)])
def vehicles(db: Session = Depends(session_dep)):
    return db.exec(select(Vehicle)).all()


@app.post("/customers", response_model=Customer, status_code=201, dependencies=[Depends(authorize)])
def add_customer(item: Customer, db: Session = Depends(session_dep)):
    item.id = None
    db.add(item); db.commit(); db.refresh(item)
    return item


@app.get("/customers", response_model=list[Customer], dependencies=[Depends(authorize)])
def customers(db: Session = Depends(session_dep)):
    return db.exec(select(Customer)).all()


@app.post("/loads", response_model=Load, status_code=201, dependencies=[Depends(authorize)])
def add_load(item: Load, db: Session = Depends(session_dep)):
    if not db.get(Customer, item.customer_id):
        raise HTTPException(404, "Customer not found")
    item.id = None
    item.status = LoadStatus.posted
    item.driver_id = None
    item.vehicle_id = None
    db.add(item); db.commit(); db.refresh(item)
    return item


@app.get("/loads", response_model=list[Load], dependencies=[Depends(authorize)])
def loads(status: Optional[LoadStatus] = None, db: Session = Depends(session_dep)):
    statement = select(Load)
    if status:
        statement = statement.where(Load.status == status)
    return db.exec(statement).all()


@app.get("/loads/{load_id}", response_model=Load, dependencies=[Depends(authorize)])
def load_detail(load_id: int, db: Session = Depends(session_dep)):
    item = db.get(Load, load_id)
    if not item:
        raise HTTPException(404, "Load not found")
    return item


@app.post("/loads/{load_id}/assign", response_model=Load, dependencies=[Depends(authorize)])
def assign(load_id: int, assignment: Assignment, db: Session = Depends(session_dep)):
    load = db.get(Load, load_id)
    driver = db.get(Driver, assignment.driver_id)
    vehicle = db.get(Vehicle, assignment.vehicle_id)
    if not load or not driver or not vehicle:
        raise HTTPException(404, "Load, driver or vehicle not found")
    if not driver.active or not vehicle.active:
        raise HTTPException(400, "Driver and vehicle must be active")
    if load.status != LoadStatus.posted:
        raise HTTPException(409, "Only posted loads can be assigned")
    if load.weight_lbs is not None and vehicle.capacity_lbs is not None and load.weight_lbs > vehicle.capacity_lbs:
        raise HTTPException(400, "Load exceeds vehicle capacity")
    load.driver_id = driver.id; load.vehicle_id = vehicle.id; load.status = LoadStatus.assigned
    db.add(LoadEvent(load_id=load_id, status=load.status, note="Assigned"))
    db.add(load); db.commit(); db.refresh(load)
    return load


TRANSITIONS = {
    LoadStatus.posted: {LoadStatus.cancelled},
    LoadStatus.assigned: {LoadStatus.picked_up, LoadStatus.cancelled},
    LoadStatus.picked_up: {LoadStatus.delivered, LoadStatus.cancelled},
    LoadStatus.delivered: set(),
    LoadStatus.cancelled: set(),
}


@app.post("/loads/{load_id}/status", response_model=Load, dependencies=[Depends(authorize)])
def update_status(load_id: int, update: StatusUpdate, db: Session = Depends(session_dep)):
    load = db.get(Load, load_id)
    if not load:
        raise HTTPException(404, "Load not found")
    if update.status not in TRANSITIONS[load.status]:
        raise HTTPException(409, f"Invalid transition: {load.status} -> {update.status}")
    load.status = update.status
    db.add(load); db.add(LoadEvent(load_id=load_id, status=update.status, note=update.note))
    db.commit(); db.refresh(load)
    return load


@app.get("/loads/{load_id}/events", response_model=list[LoadEvent], dependencies=[Depends(authorize)])
def events(load_id: int, db: Session = Depends(session_dep)):
    if not db.get(Load, load_id):
        raise HTTPException(404, "Load not found")
    return db.exec(select(LoadEvent).where(LoadEvent.load_id == load_id).order_by(LoadEvent.id)).all()


@app.post("/expenses", response_model=Expense, status_code=201, dependencies=[Depends(authorize)])
def add_expense(item: Expense, db: Session = Depends(session_dep)):
    if item.load_id is not None and not db.get(Load, item.load_id):
        raise HTTPException(404, "Load not found")
    item.id = None
    db.add(item); db.commit(); db.refresh(item)
    return item


@app.get("/expenses", response_model=list[Expense], dependencies=[Depends(authorize)])
def expenses(db: Session = Depends(session_dep)):
    return db.exec(select(Expense)).all()


@app.get("/dashboard", dependencies=[Depends(authorize)])
def dashboard(db: Session = Depends(session_dep)):
    all_loads = db.exec(select(Load)).all()
    all_expenses = db.exec(select(Expense)).all()
    revenue = sum(x.rate_usd for x in all_loads if x.status == LoadStatus.delivered)
    driver_pay = sum(x.driver_pay_usd for x in all_loads if x.status == LoadStatus.delivered)
    load_expenses = sum(x.expenses_usd for x in all_loads if x.status == LoadStatus.delivered)
    recorded_expenses = sum(x.amount_usd for x in all_expenses)
    return {
        "loads_total": len(all_loads),
        "loads_by_status": {s.value: sum(x.status == s for x in all_loads) for s in LoadStatus},
        "delivered_revenue_usd": round(revenue, 2),
        "driver_pay_usd": round(driver_pay, 2),
        "load_expenses_usd": round(load_expenses, 2),
        "recorded_expenses_usd": round(recorded_expenses, 2),
        "estimated_margin_usd": round(revenue - driver_pay - load_expenses - recorded_expenses, 2),
        "note": "Estimated margin, not accounting profit. Recorded expenses and load expenses must not duplicate each other.",
    }
