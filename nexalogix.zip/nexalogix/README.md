# NexaLogix 🚚

**Open-source starter API for a small trucking, courier, medical-courier, and dispatch operation.**

> **Status:** MVP backend, not a production-ready transportation management system (TMS). The API includes interactive documentation at `/docs`; it does not yet include a visual dispatcher dashboard.

## Features implemented

- Drivers: register, list, active status, license class and contact fields.
- Vehicles: register, list, equipment type, liftgate, capacity, insurance and inspection dates.
- Customers: contact and billing details.
- Loads: create/list/filter, pickup and delivery locations and times, weight, mileage, rate, driver pay and expenses.
- Dispatch: assign driver and vehicle; block inactive resources and overweight loads.
- Tracking workflow: posted → assigned → picked_up → delivered (or cancellation), with event history.
- Expenses: record categorized expenses and optionally link them to loads.
- KPI summary: load counts, delivered revenue, driver pay, expenses and estimated margin.
- Simple API-key protection for all business endpoints; health endpoint is public.
- SQLite persistence, Docker Compose, automated tests, GitHub Actions CI and OpenAPI documentation.

## Quick start: Windows 11 / PowerShell

Install Python 3.12+ and Git. In PowerShell:

```powershell
git clone https://github.com/YOUR_USERNAME/nexalogix.git
cd nexalogix
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set a strong random `DISPATCH_API_KEY`. **PowerShell does not load `.env` automatically**, so set the environment variable before running:

```powershell
$env:DISPATCH_API_KEY="YOUR_LONG_SECRET_FROM_ENV_FILE"
uvicorn app.main:app --reload
```

Visit http://127.0.0.1:8000/docs. Click **Authorize** and enter the API key. Try `POST /customers`, then `POST /drivers`, `POST /vehicles`, `POST /loads`, and assign the load. `/health` needs no key.

## Docker (recommended for a quick local setup)

```bash
cp .env.example .env
# Edit .env and set DISPATCH_API_KEY to a strong secret
docker compose up --build -d
```

Open http://127.0.0.1:8000/docs. SQLite data persists in the `dispatch_data` Docker volume. Do not publish port 8000 directly on the internet.

## Tests

```bash
pytest -q
```

## Example: create a customer

```bash
curl -X POST http://127.0.0.1:8000/customers \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: YOUR_LONG_SECRET' \
  -d '{"name":"Example Customer","email":"ops@example.com"}'
```

## Project structure

```text
app/main.py                 FastAPI models, persistence and endpoints
app/__init__.py             Python package
 tests/test_api.py           API flow test
.github/workflows/ci.yml    Continuous integration
Dockerfile                  Container image
docker-compose.yml          Local Docker stack
.env.example                Environment variable template
requirements.txt            Dependencies
ROADMAP.md                  Future feature plan
```

## Security and operational limits

- **Local-development MVP only.** One shared API key is not sufficient for a multi-user or internet-facing service. Before production: add user accounts, role-based access, audit logging, HTTPS reverse proxy, rate limits, secrets management, database migrations, backups and recovery tests.
- The current API uses `float` for USD amounts; use fixed-precision decimals or integer cents before processing real payments.
- This tool does not verify DOT/MC/UCR authority, CDL eligibility, medical certifications, insurance, HOS, HIPAA compliance or legal requirements. Obtain independent compliance review before operating.
- Do not store patient information, medical records, payment-card details, government IDs, or other sensitive personal data in this MVP.
- No GPS tracking, mapping, billing automation, document uploads or route optimization is implemented yet.
- SQLite is suitable for local testing, not multi-user production workloads.
- Dashboard margin is an estimate, not an accounting statement. Do not record the same expense in both load expenses and the expense ledger.

## License

MIT — see LICENSE.
