# Roadmap — suggested next modules (not implemented)

## Phase 1: Operations
- Responsive web dispatcher dashboard with map and drag-and-drop load board
- Driver mobile app, availability calendar, dispatch notifications and proof of delivery
- Pickup/drop-off stops, ETA, GPS check-ins, route optimization, traffic and geofencing
- Quotes, recurring routes, customer portal and automated status updates
- Driver/vehicle assignment conflict detection and maintenance scheduling

## Phase 2: Business and finance
- Invoicing, payments, customer statements, broker/carrier settlement and factoring exports
- Fuel/toll/maintenance tracking, cost-per-mile and profit-per-load reports
- Document storage (BOL, POD, insurance, W-9) and electronic signatures
- CRM, lead pipeline, follow-up reminders, contracts and customer onboarding
- Import/export CSV, accounting integrations, multi-tenant accounts and granular permissions

## Phase 3: Compliance and advanced tools
- Expiry alerts for insurance, inspections, licenses, DOT medical cards and registrations
- Audit logs, backups, retention policies, role-based permissions, MFA and monitoring
- Optional ELD/telematics and load-board integrations subject to vendor approval
- Multi-stop routing and dispatch suggestions with explainable constraints
- Bilingual English/Spanish interface, accessibility and mobile-first design
- Secure cloud deployment with PostgreSQL, migrations, encryption and observability

> Specialized workflows (medical courier, hazardous goods, interstate trucking) require independent regulatory review and appropriate security controls.
